
public class Main {

	public static void main(String[] args) {
		PizzaStore nystore = new PizzaStore();
		
		Order order1 = new Order (1, new CheesePizza(), 2);
		nystore.getOrder(order1);
		nystore.makePizza(order1);
		
		Order order2 = new Order (2, new HawaiiPizza(), 1);
		nystore.getOrder(order2);
		nystore.makePizza(order2);		
	}
}
