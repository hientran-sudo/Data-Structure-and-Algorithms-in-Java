
public  class PizzaStore {
	public Order getOrder(Order order) {
		 order.prepare();
		 return order;
	}
		
	public Order makePizza(Order order) {
		order.make();
		return order;		
	}
}
