
public abstract class Pizza {
	String name, dough, sauce, toppings;
	
	public String getName() {
		return name;
	}
	public String getDough() {
		return dough;
	}
	public String getSauce() {
		return sauce;
	}
	public String getToppings() {
		return toppings;
	}
}
