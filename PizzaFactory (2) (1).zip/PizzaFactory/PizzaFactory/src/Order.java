public class Order {
	int id;
	int number;
	Pizza pizza;
	public Order (int id, Pizza pizza, int number) {
		this.id = id;
		this.number = number;
		this.pizza = pizza;		
	}
	
	public void prepare() {
		System.out.println("Prepare order: " + id);
		System.out.println("Type of pizza: " + pizza.getName());
		System.out.println("Qty: " + number + "\n");
		   
	}
	public void make() {
		for (int i = 0; i < number; i++) {
			System.out.println("Making " + pizza.getName());
			System.out.println("Tossing " + pizza.getDough() + " dough");
		    System.out.println("Adding " + pizza.getSauce() + " sauce");
		    System.out.println("Adding " + pizza.getToppings() + " toppings" + "\n");
		}		
	}
}
