
public class NYStore extends PizzaStore{

}
