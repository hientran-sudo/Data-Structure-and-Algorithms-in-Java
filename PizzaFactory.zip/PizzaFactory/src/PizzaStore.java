
public abstract class PizzaStore {
		
	public Pizza makePizza(Pizza p) {
		p.prepare();
		return p;		
	}
}
