
public abstract class Pizza {
	String name, dough, sauce, toppings;
	public void prepare()
	   {
	       System.out.println("Making " + name);
	       System.out.println("Tossing " + dough + " dough");
	       System.out.println("Adding " + sauce + " sauce");
	       System.out.println("Adding " + toppings + " toppings");
	   }
}
