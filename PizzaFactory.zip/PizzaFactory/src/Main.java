
public class Main {

	public static void main(String[] args) {
		PizzaStore nystore = new NYStore();
		
		nystore.makePizza(new CheesePizza());
		nystore.makePizza(new HawaiiPizza());
	}
}
