import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		PizzaStore nystore = new PizzaStore();
		
		List <Item> order1 = new ArrayList<>();
		order1.add(new Item (1, new CheesePizza(), 2));
		order1.add(new Item (2, new HawaiiPizza(), 1));
		
		System.out.println("Order has: " );		
		for (Item i : order1) {
			nystore.getItem(i);			
		}
		
		System.out.println("Prepare order:" );
		for (Item i : order1) {
			nystore.makePizza(i);
		}			
		}
		
}
