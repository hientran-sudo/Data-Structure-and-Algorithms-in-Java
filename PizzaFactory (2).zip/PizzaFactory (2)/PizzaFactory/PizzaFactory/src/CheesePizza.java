
public class CheesePizza extends Pizza{
	public CheesePizza () {
		name = "Cheese pizza";
		dough = "thin crust";
		sauce = "tomatoes";
		toppings = "mozzarella cheese";
	}
}
