
public class HawaiiPizza extends Pizza{
	public HawaiiPizza () {
		name = "Hawaii pizza";
		dough = "thick crust";
		sauce = "tomatoes";
		toppings = "pineapple, ham, mozzarella cheese";		
	}
}
