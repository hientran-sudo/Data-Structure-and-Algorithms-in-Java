
public  class PizzaStore {
	public Item getItem(Item item) {
		 item.prepare();
		 return item;
	}
		
	public Item makePizza(Item item) {
		item.make();
		return item;		
	}
}
